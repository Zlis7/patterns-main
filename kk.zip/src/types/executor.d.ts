interface IExecutorCommand{
  command: string;
  args: string[];
}

interface IExecutorCommandFfmpeg extends IExecutorCommand{
  ouput: string;
}

