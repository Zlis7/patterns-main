interface IFfmpegInput {
  width: number;
  height: number;
  path: string;
  name: string;
}


