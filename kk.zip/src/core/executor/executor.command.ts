import { ChildProcessWithoutNullStreams } from "child_process";

export abstract class AbstractExecutorCommand<Input>{
  constructor(private logger: IStreamLogger){}

  public async execute(): Promise<void>{
    const input = await this.prompt()
    const command = this.build(input);
    const stream = this.spawn(command);
    this.processStream(stream, this.logger);
  };

  protected abstract prompt(): Promise<Input>;
  protected abstract build(input: Input): IExecutorCommand;
  protected abstract spawn(command: IExecutorCommand): ChildProcessWithoutNullStreams;
  protected abstract processStream(
    stream: ChildProcessWithoutNullStreams,
    logger: IStreamLogger
  ): void;
}