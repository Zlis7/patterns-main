type PromptType = 'input' | 'number' | 'password';
