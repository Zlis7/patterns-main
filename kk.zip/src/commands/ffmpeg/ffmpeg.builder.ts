export class FfmpegBuilder {
  private _inputPath!: string;
  private options: Map<string, string> = new Map();

  constructor() {
    this.options.set('-c:v', 'libx264');
  }

  setInputPath(path: string): this {
    this._inputPath = path;
    return this;
  }

  output(path: string): string[] {
    const args: string[] = ['-i', this._inputPath];

    this.options.forEach((value, key) => {
      args.push(key);
      args.push(value);
    });

    args.push(path);

    return args;
  }

  setVideoSize(width: number, height: number): this {
    this.options.set('-s', `${width}x${height}`);
    return this;
  }
}
